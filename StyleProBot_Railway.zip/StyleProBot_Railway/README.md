
# StylePro Telegram Bot for Railway

## 📦 Как запустить на Railway:
1. Залей этот проект в GitHub.
2. Перейди на [https://railway.app](https://railway.app) → New Project → Deploy from GitHub.
3. В Settings добавь переменную окружения `TOKEN` — вставь свой токен от BotFather.
4. Railway соберёт и запустит бота автоматически.
